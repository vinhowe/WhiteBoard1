﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Intro
    Inherits System.Windows.Forms.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Intro))
        Me.Background = New System.Windows.Forms.Panel()
        Me.BeginLabel = New System.Windows.Forms.Label()
        Me.Copyright = New System.Windows.Forms.Label()
        Me.specialInfo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CSB = New System.Windows.Forms.Button()
        Me.Background.SuspendLayout()
        Me.SuspendLayout()
        '
        'Background
        '
        Me.Background.BackColor = System.Drawing.Color.White
        Me.Background.BackgroundImage = Global.SparkONCA.My.Resources.Resources.IntroBackgroundImage
        Me.Background.Controls.Add(Me.BeginLabel)
        Me.Background.Controls.Add(Me.Copyright)
        Me.Background.Controls.Add(Me.specialInfo)
        Me.Background.Controls.Add(Me.Label1)
        Me.Background.Controls.Add(Me.CSB)
        Me.Background.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Background.Location = New System.Drawing.Point(0, 0)
        Me.Background.Name = "Background"
        Me.Background.Size = New System.Drawing.Size(767, 444)
        Me.Background.TabIndex = 3
        '
        'BeginLabel
        '
        Me.BeginLabel.BackColor = System.Drawing.Color.Transparent
        Me.BeginLabel.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BeginLabel.Location = New System.Drawing.Point(181, 239)
        Me.BeginLabel.Name = "BeginLabel"
        Me.BeginLabel.Size = New System.Drawing.Size(397, 25)
        Me.BeginLabel.TabIndex = 0
        Me.BeginLabel.Text = "Online Note board collaboration application" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.BeginLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Copyright
        '
        Me.Copyright.AutoSize = True
        Me.Copyright.BackColor = System.Drawing.Color.Transparent
        Me.Copyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Copyright.Location = New System.Drawing.Point(12, 423)
        Me.Copyright.Name = "Copyright"
        Me.Copyright.Size = New System.Drawing.Size(51, 13)
        Me.Copyright.TabIndex = 1
        Me.Copyright.Text = "Copyright"
        '
        'specialInfo
        '
        Me.specialInfo.AutoSize = True
        Me.specialInfo.BackColor = System.Drawing.Color.Transparent
        Me.specialInfo.Font = New System.Drawing.Font("Consolas", 7.25!)
        Me.specialInfo.Location = New System.Drawing.Point(527, 425)
        Me.specialInfo.Name = "specialInfo"
        Me.specialInfo.Size = New System.Drawing.Size(60, 12)
        Me.specialInfo.TabIndex = 3
        Me.specialInfo.Text = "specialInfo"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Harlow Solid Italic", 72.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(151, 115)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(447, 121)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Spark"
        '
        'CSB
        '
        Me.CSB.BackColor = System.Drawing.Color.Transparent
        Me.CSB.FlatAppearance.BorderSize = 0
        Me.CSB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.CSB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CSB.Location = New System.Drawing.Point(328, 311)
        Me.CSB.Name = "CSB"
        Me.CSB.Size = New System.Drawing.Size(74, 34)
        Me.CSB.TabIndex = 2
        Me.CSB.Text = "Start"
        Me.CSB.UseVisualStyleBackColor = False
        '
        'Intro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(767, 444)
        Me.Controls.Add(Me.Background)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Intro"
        Me.Text = "Spark"
        Me.Background.ResumeLayout(False)
        Me.Background.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Copyright As System.Windows.Forms.Label
    Friend WithEvents Background As System.Windows.Forms.Panel
    Friend WithEvents BeginLabel As System.Windows.Forms.Label
    Friend WithEvents specialInfo As System.Windows.Forms.Label
    Friend WithEvents CSB As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
