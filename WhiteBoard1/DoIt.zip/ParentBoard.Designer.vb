﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ParentBoard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ParentBoard))
        Me.ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.AddIdeaButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip
        '
        Me.ToolStrip.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddIdeaButton})
        Me.ToolStrip.Location = New System.Drawing.Point(0, 726)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip.Size = New System.Drawing.Size(884, 36)
        Me.ToolStrip.TabIndex = 0
        Me.ToolStrip.Text = "ToolStrip1"
        '
        'AddIdeaButton
        '
        Me.AddIdeaButton.BackColor = System.Drawing.Color.Transparent
        Me.AddIdeaButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.AddIdeaButton.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddIdeaButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AddIdeaButton.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.AddIdeaButton.Name = "AddIdeaButton"
        Me.AddIdeaButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AddIdeaButton.Size = New System.Drawing.Size(30, 33)
        Me.AddIdeaButton.Text = "+"
        Me.AddIdeaButton.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.AddIdeaButton.ToolTipText = "Add an Idea"
        '
        'ParentBoard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(884, 762)
        Me.Controls.Add(Me.ToolStrip)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ParentBoard"
        Me.Text = "Spark"
        Me.ToolStrip.ResumeLayout(False)
        Me.ToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents AddIdeaButton As System.Windows.Forms.ToolStripButton
End Class
