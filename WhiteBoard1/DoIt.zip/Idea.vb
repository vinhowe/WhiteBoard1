﻿Public Class Idea
    'Declare the variables
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer
    Dim NameInfoEn As Boolean = False
    Dim UserInfoEn As Boolean = False
    Dim LdescboxEn As Boolean = False
    Dim SdescboxEn As Boolean = False
    Dim currentTime As String = System.DateTime.Now.ToString("hh:mm:ss")
    Dim expand As Integer = 1
    Dim expandsix As Integer = 6
    Dim decreasefive As Integer = 5
    Dim expandtwo As Integer = 2
    Dim DetermineMouseClick As Integer

    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub TopPanel_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TopPanel.MouseDown
        drag = True 'Sets the variable drag to true.
        mousex = Windows.Forms.Cursor.Position.X - Me.Left 'Sets variable mousex
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top 'Sets variable mousey
        Me.BringToFront()
    End Sub

    Private Sub TopPanel_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TopPanel.MouseMove
        'If drag is set to true then move the form accordingly.
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TopPanel.MouseUp
        drag = False 'Sets drag to false, so the form does not move according to the code in MouseMove
    End Sub


    Private Sub Idea_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DateInfo.Text = Now.Month & "/" & Now.Day & "/" & Now.Year
        TimeInfo.Text = currentTime
        Me.ClientSize = New System.Drawing.Size(240, 310)
    End Sub

    Private Sub ImageAddDialog_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ImageAddDialog.FileOk
        IdeaBox.ImageLocation = ImageAddDialog.FileName
    End Sub

    Private Sub IdeaBox_Click(sender As Object, e As EventArgs) Handles IdeaBox.Click
        OpenImage()
    End Sub

    Private Sub OpenImage()
        ImageAddDialog.ShowDialog()
    End Sub

    Private Sub NameInfo_DoubleClick(sender As Object, e As EventArgs) Handles NameInfo.DoubleClick
        If NameInfoEn = False Then
            NameInfo.ReadOnly = False
        Else
            NameInfo.ReadOnly = True
        End If
    End Sub

    Private Sub NameInfo_MouseLeave(sender As Object, e As EventArgs) Handles NameInfo.MouseLeave
        NameInfo.ReadOnly = True
    End Sub

    Private Sub UserInfo_DoubleClick(sender As Object, e As EventArgs) Handles UserInfo.DoubleClick
        If UserInfoEn = False Then
            UserInfo.ReadOnly = False
        Else
            UserInfo.ReadOnly = True
        End If
    End Sub

    Private Sub UserInfo_MouseLeave(sender As Object, e As EventArgs) Handles UserInfo.MouseLeave
        UserInfo.ReadOnly = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Me.Size.Width = 240 And Me.Size.Height = 310 Then
            expand = 2
            SweepingTimer.Enabled = True
            Button1.Text = "<"
        ElseIf Me.Size.Width = 480 And Me.Size.Height = 310 Then
            expand = 1
            SweepingTimer.Enabled = True
            Button1.Text = ">"
        End If
    End Sub

    Private Sub SweepingTimer_Tick(sender As Object, e As EventArgs) Handles SweepingTimer.Tick
        If expand = 1 Then
            If Me.Size.Width = 240 And Me.Size.Height = 310 Then
                decreasefive = 5
                If SmallButtonBorder.Visible = False Then
                    SmallButtonBorder.Visible = True
                End If
                SweepingTimer.Enabled = False
            Else
                Me.ClientSize = New System.Drawing.Size(Me.Size.Width - expandsix, 310)
            End If
        ElseIf expand = 2 Then
            If SmallButtonBorder.Visible = True Then
                SmallButtonBorder.Visible = False
            End If
            If Me.Size.Width = 480 And Me.Size.Height = 310 Then
                SweepingTimer.Enabled = False
            Else
                Me.ClientSize = New System.Drawing.Size(Me.Size.Width + expandsix, 310)
            End If
        End If
    End Sub

    Private Sub Ldescbox_DoubleClick(sender As Object, e As EventArgs) Handles Ldescbox.DoubleClick
        If LdescboxEn = False Then
            Ldescbox.ReadOnly = False
        Else
            Ldescbox.ReadOnly = True
        End If
    End Sub

    Private Sub Ldescbox_MouseLeave(sender As Object, e As EventArgs) Handles Ldescbox.MouseLeave
        Ldescbox.ReadOnly = True
    End Sub

    Private Sub Sdescbox_DoubleClick(sender As Object, e As EventArgs) Handles Sdescbox.DoubleClick
        If SdescboxEn = False Then
            Sdescbox.ReadOnly = False
        Else
            Sdescbox.ReadOnly = True
        End If
    End Sub

    Private Sub Sdescbox_MouseLeave(sender As Object, e As EventArgs) Handles Sdescbox.MouseLeave
        Sdescbox.ReadOnly = True
    End Sub

    Private Sub Sdescbox_TextChanged(sender As Object, e As EventArgs) Handles Sdescbox.TextChanged
        Ldescbox.Text = Sdescbox.Text
    End Sub

    Private Sub Ldescbox_TextChanged(sender As Object, e As EventArgs) Handles Ldescbox.TextChanged
        Sdescbox.Text = Ldescbox.Text
    End Sub
End Class