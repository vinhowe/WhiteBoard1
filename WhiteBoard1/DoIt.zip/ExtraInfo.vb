﻿Public Class ExtraInfo

    Public Shared ExInfo As String = ""

End Class
