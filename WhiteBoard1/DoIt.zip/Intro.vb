﻿Public Class Intro

    Private Sub Intro_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Copyright.Text = My.Application.Info.Copyright
        Me.specialInfo.Text = ExtraInfo.ExInfo
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles CSB.Click
        ParentBoard.Show()
        Me.Close()
    End Sub

End Class
