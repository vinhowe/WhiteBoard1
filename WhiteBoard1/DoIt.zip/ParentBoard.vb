﻿Public Class ParentBoard
    Dim Note As New Idea
    Private Sub AddIdeaButton_Click(sender As Object, e As EventArgs) Handles AddIdeaButton.Click
        Note = New Idea
        Note.TopLevel = False
        Note.Visible = True
        Me.Controls.Add(Note)
    End Sub

    Private Sub ParentBoard_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Show()
        If ExitDialog.CloseConsent = True Then
            Return
        Else
            ExitDialog.ShowDialog()
        End If

    End Sub
End Class